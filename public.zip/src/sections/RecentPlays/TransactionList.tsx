import React, { useState, useEffect } from 'react';

function TransactionList() {
  const [transactions, setTransactions] = useState<any[]>([]);

  // Pre-load 10 items initially
  useEffect(() => {
    const initialTransactions = Array.from({ length: 10 }, () => createRandomTransaction());
    setTransactions(initialTransactions);

    const interval = setInterval(() => {
      setTransactions((prev) => [createRandomTransaction(), ...prev].slice(0, 10)); // Keep the latest 10 transactions
    }, 2000); // Update every 2 seconds

    return () => clearInterval(interval); // Cleanup on component unmount
  }, []);

  // Create a random transaction entry
  const createRandomTransaction = () => {
    const gameImages = [
      '/games/dice.png',
      '/games/roulette.png',
      '/games/slots.png',
      '/games/hilo.png',
      '/games/mines.png',
      '/games/crash.png',
    ];

    // Randomly pick a token
    const tokens = ['FAKE', 'SOL', 'USDC', 'Wormhole', 'H8C'];
    const token = tokens[Math.floor(Math.random() * tokens.length)];

    // Define wager logic based on the token
    let wagerAmount = 0;
    if (token === 'FAKE') {
      wagerAmount = (Math.random() * 2 + 1).toFixed(2); // FAKE: More than 1 FAKE
    } else if (token === 'SOL') {
      wagerAmount = (Math.random() * 0.2 + 0.05).toFixed(2); // SOL: More than 0.05 SOL
    } else if (token === 'USDC') {
      wagerAmount = (Math.random() * 0.8 + 0.2).toFixed(2); // USDC: More than 0.2 USDC
    } else {
      wagerAmount = (Math.random() * 2 + 1).toFixed(2); // Wormhole and H8C: More than 1 token
    }

    // Determine if the player wins or loses
    const isWin = Math.random() > 0.5;
    const multiplier = isWin ? (Math.random() > 0.5 ? 2 : 0.5) : 0; // 2x or 0.5x for win, 0x for loss
    const payout = multiplier > 0 ? (parseFloat(wagerAmount) * multiplier).toFixed(2) : `-${wagerAmount}`; // Calculate payout based on win or loss

    // Generate transaction data
    const transaction = {
      transactionId: Math.random().toString(36).substring(2, 15),
      game: gameImages[Math.floor(Math.random() * gameImages.length)],
      player: `0x${Math.random().toString(36).substring(2, 12).toUpperCase()}`, // Crypto wallet address format
      wager: `${wagerAmount} ${token}`,
      multiplier: multiplier > 0 ? `${multiplier}x` : '0x', // Show 0x for loss
      payout: `${payout} ${token}`, // Payout with the token symbol
      token,
      time: new Date().toLocaleTimeString(),
      hash: Math.random().toString(36).substring(2, 12) + '...' // Random hash, truncated
    };

    return transaction;
  };

  return (
    <div className="overflow-y-auto max-h-80">
      {/* Header */}
      <div className="hidden sm:flex items-center mb-4 p-3 rounded-xl border border-[rgba(168,168,168,0.1)] bg-[#171919]">
        <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">Transaction</div>
        <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">Game</div>
        <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">Player</div>
        <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">Wager</div>
        <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">Multiplier</div>
        <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">Payout</div>
        <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">Token</div>
      </div>

      {/* Transaction List */}
      {transactions.map((transaction, index) => (
        <div key={index} className="flex items-center mb-4 p-3 rounded-xl border border-[rgba(168,168,168,0.1)] bg-[#171919]">
          <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">{transaction.transactionId}</div>
          <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">
            <img alt={transaction.game} className="w-10 h-10 rounded-full" src={transaction.game} />
          </div>
          <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">{transaction.player}</div>
          <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">{transaction.wager}</div>
          <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">{transaction.multiplier}</div>
          <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">{transaction.payout}</div>
          <div className="flex-1 flex items-center justify-center text-[#EDE1CE] text-[14px] font-normal leading-[21px]">{transaction.token}</div>
        </div>
      ))}
    </div>
  );
}

export default TransactionList;
