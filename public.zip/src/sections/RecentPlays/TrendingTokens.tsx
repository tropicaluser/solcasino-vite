import React, { useState, useEffect } from 'react';

// Define a type for the token object
interface Token {
  id: string;
  symbol: string;
  name: string;
  large: string;
  currentPrice: number;
  priceChange24h: number;
}

function TrendingTokens() {
  const [tokens, setTokens] = useState<Token[]>([]); // Use the Token type for the state

  useEffect(() => {
    async function fetchTrendingTokens() {
      try {
        const trendingResponse = await fetch('https://api.coingecko.com/api/v3/search/trending');
        const trendingData = await trendingResponse.json();

        // Fetch the price and 24-hour % change for each trending coin
        const coinIds = trendingData.coins.slice(0, 15).map(coin => coin.item.id);
        const marketsResponse = await fetch(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${coinIds.join(',')}`);
        const marketsData = await marketsResponse.json();

        // Combine both data sources (trending data and market data)
        const updatedTokens = trendingData.coins.slice(0, 15).map(coin => {
          const marketData = marketsData.find(market => market.id === coin.item.id);
          return {
            ...coin.item,
            currentPrice: marketData ? marketData.current_price : 0,
            priceChange24h: marketData ? marketData.price_change_percentage_24h : 0,
          };
        });

        setTokens(updatedTokens);
      } catch (error) {
        console.error('Error fetching trending tokens:', error);
      }
    }

    fetchTrendingTokens();
  }, []);

  return (
    <div className="flex flex-col gap-4 rounded-xl border border-[rgba(168,168,168,0.10)] bg-[#171919] p-4">
      <div className="flex justify-between items-center">
        <div className="flex items-center justify-center gap-1">
          <img alt="" loading="lazy" width="36" height="30" decoding="async" className="w-[20px]" src="https://www.guacamole.gg/images/v3/Flaming_Onion_Guacamole.svg" style={{ color: 'transparent' }} />
          <h2 className="text-[#ADD951] text-[16px] font-bold leading-[96.875%] tracking-[-0.48px]">Trending Tokens</h2>
        </div>
        <a className="text-[#ADD951] hover:underline" href="/trade">Trade Now</a>
      </div>
      <div className="overflow-x-auto">
        <div className="flex min-w-max gap-1 pb-4" id="trending-tokens">
          {tokens.map((coin) => (
            <div key={coin.id} className="flex-shrink-0 flex flex-col items-center gap-1 bg-[#101212] rounded-[10px] w-[147px] h-[160px] border border-[rgba(168,168,168,0.10)] mr-4 overflow-hidden p-[3px]">
              <div className="w-full p-2 h-[64px] flex gap-2 rounded-[8px] bg-gradient-to-b from-[rgba(173,217,81,0.15)] to-[rgba(92,115,43,0.15)]">
                <img alt={coin.name} loading="lazy" width="40" height="40" decoding="async" className="rounded-full w-[40px] h-[40px]" src={coin.large} style={{ color: 'transparent' }} />
                <div className="flex flex-col">
                  <span className="text-[#EDE1CE] font-urbanist text-[12px] font-bold leading-normal tracking-[-0.32px]">{coin.symbol.toUpperCase()}</span>
                </div>
              </div>
              <div className="flex flex-col items-start w-full mt-2 pl-[15px]">
                <span className="text-[#EDE1CE] font-urbanist text-[14px] font-bold leading-normal tracking-[-0.4px]">${coin.currentPrice.toFixed(7)}</span>
                <span className={`font-urbanist text-[12px] font-bold leading-normal tracking-[-0.24px] ${coin.priceChange24h > 0 ? 'text-[#29D300]' : 'text-[#F44336]'}`}>
                  {coin.priceChange24h.toFixed(2)}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default TrendingTokens;
