import { GambaUi, TokenValue, useCurrentPool, useGambaPlatformContext, useUserBalance } from 'gamba-react-ui-v2'
import React from 'react'
import { NavLink } from 'react-router-dom'
import styled from 'styled-components'
import { Modal } from '../components/Modal'
import { PLATFORM_JACKPOT_FEE } from '../constants'
import TokenSelect from './TokenSelect'
import { UserButton } from './UserButton'

const Bonus = styled.button`
  all: unset;
  cursor: pointer;
  color: #003c00;
  border-radius: 10px;
  background: #03ffa4;
  padding: 2px 10px;
  font-size: 12px;
  text-transform: uppercase;
  font-weight: bold;
  transition: background-color .2s;
  &:hover {
    background: white;
  }
`

const StyledHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding: 10px;
  background: rgba(33, 34, 51, 0.9);
  position: fixed;
  background: #000000CC;
  backdrop-filter: blur(20px);
  top: 0;
  left: 0;
  z-index: 1000;
  backdrop-filter: blur(20px);
`

const Logo = styled(NavLink)`
  height: 35px;
  margin: 0 10px;
  & > img {
    height: 100%;
  }
`

export default function Header() {
  const pool = useCurrentPool()
  const context = useGambaPlatformContext()
  const balance = useUserBalance()
  const [bonusHelp, setBonusHelp] = React.useState(false)
  const [jackpotHelp, setJackpotHelp] = React.useState(false)

  return (
    <>
      {bonusHelp && (
        <Modal onClose={() => setBonusHelp(false)}>
          <h1>Bonus ✨</h1>
          <p>
            You have <b><TokenValue amount={balance.bonusBalance} /></b> worth of free plays. This bonus will be applied automatically when you play.
          </p>
          <p>
            Note that a fee is still needed from your wallet for each play.
          </p>
        </Modal>
      )}
      {jackpotHelp && (
        <Modal onClose={() => setJackpotHelp(false)}>
          <h1>Jackpot 💰</h1>
          <p style={{ fontWeight: 'bold' }}>
            There{'\''}s <TokenValue amount={pool.jackpotBalance} /> in the Jackpot.
          </p>
          <p>
            The Jackpot is a prize pool that grows with every bet made. As the Jackpot grows, so does your chance of winning. Once a winner is selected, the value of the Jackpot resets and grows from there until a new winner is selected.
          </p>
          <p>
            You will be paying a maximum of {(PLATFORM_JACKPOT_FEE * 100).toLocaleString(undefined, { maximumFractionDigits: 4 })}% for each wager for a chance to win.
          </p>
          <label style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            {context.defaultJackpotFee === 0 ? 'DISABLED' : 'ENABLED'}
            <GambaUi.Switch
              checked={context.defaultJackpotFee > 0}
              onChange={(checked) => context.setDefaultJackpotFee(checked ? PLATFORM_JACKPOT_FEE : 0)}
            />
          </label>
        </Modal>
      )}
      <StyledHeader>
      <link
          rel="stylesheet"
          href="src/sections/pumpcasino.css"
        />
        <div style={{ display: '', gap: '20px', alignItems: 'center' }}>      

<header class="sticky top-5 z-40 w-[calc(100%-30px)] mx-auto rounded-xl bg-[#171919] h-[72px] border max-w-[1379px] mb-4"><div class="w-full h-full px-3" bis_skin_checked="1"><div class="flex items-center justify-between w-full h-full" bis_skin_checked="1"><a class="flex items-center gap-2" href="/"><div class="hidden sm:block" bis_skin_checked="1"> <h1 class="logo">Fluto Game</h1></div><div class="block sm:hidden" bis_skin_checked="1"><svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.29304 30.3471C1.26343 30.6229 0.321085 29.6805 0.596813 28.6509L2.85972 20.2009C3.15503 19.0982 4.7555 18.8072 5.69298 19.4599C7.80527 20.9306 10.6834 21.3173 13.3692 19.7724L13.7701 19.5418C14.6096 19.0589 15.6266 18.9951 16.5207 19.3693C18.8231 20.333 20.1287 22.4097 20.309 24.5849C20.3553 25.1429 19.9535 25.6177 19.4128 25.7625L2.29304 30.3471Z" fill="#ADD951"></path><path d="M29.1037 23.1672L23.2987 24.7218C22.4639 24.9454 21.6452 24.3046 21.4588 23.4603C20.9628 21.2136 19.4507 19.1781 17.0248 18.1627C15.7546 17.6311 14.3098 17.7217 13.1171 18.4077L12.7162 18.6383C10.1626 20.1071 7.39664 19.4422 5.64794 17.7315C4.33123 16.4433 4.40877 14.4166 4.88495 12.6384L7.77671 1.84021C8.05244 0.810606 9.33944 0.465943 10.0933 1.21982L29.7241 20.8506C30.478 21.6045 30.1334 22.8915 29.1037 23.1672Z" fill="#ADD951"></path></svg></div></a><div class="flex items-center h-full space-x-4 sm:space-x-6 sm:justify-normal justify-start" bis_skin_checked="1"><a class="flex items-center gap-1 px-2 sm:px-4 h-full border-customBorder text-white text-center font-urbanist text-xs sm:text-sm font-semibold leading-4" href="/trade"><div class="hidden sm:block" bis_skin_checked="1"><svg width="41" height="40" viewBox="0 0 41 40" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="0.110001" width="40" height="40" rx="8" fill="#ECFEFF" fill-opacity="0.05"></rect><path d="M25 14L22 17H24.25V22.25C24.25 23.075 23.575 23.75 22.75 23.75C21.925 23.75 21.25 23.075 21.25 22.25V17C21.25 15.3425 19.9075 14 18.25 14C16.5925 14 15.25 15.3425 15.25 17V22.25H13L16 25.25L19 22.25H16.75V17C16.75 16.175 17.425 15.5 18.25 15.5C19.075 15.5 19.75 16.175 19.75 17V22.25C19.75 23.9075 21.0925 25.25 22.75 25.25C24.4075 25.25 25.75 23.9075 25.75 22.25V17H28L25 14Z" fill="#EDE1CE"></path></svg></div>Trade</a><a class="flex items-center gap-1 px-2 sm:px-4 h-full border-customBorder text-white text-center font-urbanist text-xs sm:text-sm font-semibold leading-4" href="/pools"><div class="hidden sm:block" bis_skin_checked="1"><svg xmlns="http://www.w3.org/2000/svg" width="41" height="40" viewBox="0 0 41 40" fill="none"><rect x="0.519989" width="40" height="40" rx="8" fill="#ECFEFF" fill-opacity="0.05"></rect><path d="M17.0625 13C15.3738 13 14 14.3738 14 16.0625C14 17.7512 15.3738 19.125 17.0625 19.125C18.7512 19.125 20.125 17.7512 20.125 16.0625C20.125 14.3738 18.7512 13 17.0625 13ZM17.0625 17.375C16.3363 17.375 15.75 16.7887 15.75 16.0625C15.75 15.3363 16.3363 14.75 17.0625 14.75C17.7887 14.75 18.375 15.3363 18.375 16.0625C18.375 16.7887 17.7887 17.375 17.0625 17.375ZM24.9375 20.875C23.2487 20.875 21.875 22.2487 21.875 23.9375C21.875 25.6263 23.2487 27 24.9375 27C26.6263 27 28 25.6263 28 23.9375C28 22.2487 26.6263 20.875 24.9375 20.875ZM24.9375 25.25C24.2113 25.25 23.625 24.6637 23.625 23.9375C23.625 23.2113 24.2113 22.625 24.9375 22.625C25.6637 22.625 26.25 23.2113 26.25 23.9375C26.25 24.6637 25.6637 25.25 24.9375 25.25ZM15.2337 27L14 25.7663L26.7663 13L28 14.2337L15.2337 27Z" fill="#EDE1CE"></path></svg></div>Pools</a><a class="flex items-center gap-1 px-2 sm:px-4 h-full border-customBorder text-white text-center font-urbanist text-xs sm:text-sm font-semibold leading-4" href="/play"><div class="hidden sm:block" bis_skin_checked="1"><svg width="41" height="40" viewBox="0 0 41 40" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="0.669983" width="40" height="40" rx="8" fill="#ECFEFF" fill-opacity="0.05"></rect><path d="M22.7895 19.7105L21.6842 18.6053L23.7368 16.5526L21.6842 14.5L22.7895 13.3947L24.8421 15.4474L26.8947 13.3947L28 14.5L25.9474 16.5526L28 18.6053L26.8947 19.7105L24.8421 17.6579L22.7895 19.7105ZM13 20.1053L16.9474 13L20.8947 20.1053H13ZM16.9474 28C16.0789 28 15.3355 27.6908 14.7171 27.0724C14.0987 26.4539 13.7895 25.7105 13.7895 24.8421C13.7895 23.9605 14.0987 23.2138 14.7171 22.602C15.3355 21.9901 16.0789 21.6842 16.9474 21.6842C17.8158 21.6842 18.5592 21.9934 19.1776 22.6118C19.7961 23.2303 20.1053 23.9737 20.1053 24.8421C20.1053 25.7105 19.7961 26.4539 19.1776 27.0724C18.5592 27.6908 17.8158 28 16.9474 28ZM16.9474 26.4211C17.3816 26.4211 17.7533 26.2664 18.0625 25.9572C18.3717 25.648 18.5263 25.2763 18.5263 24.8421C18.5263 24.4079 18.3717 24.0362 18.0625 23.727C17.7533 23.4178 17.3816 23.2632 16.9474 23.2632C16.5132 23.2632 16.1414 23.4178 15.8322 23.727C15.523 24.0362 15.3684 24.4079 15.3684 24.8421C15.3684 25.2763 15.523 25.648 15.8322 25.9572C16.1414 26.2664 16.5132 26.4211 16.9474 26.4211ZM15.6842 18.5263H18.2105L16.9474 16.2566L15.6842 18.5263ZM21.6842 28V21.6842H28V28H21.6842ZM23.2632 26.4211H26.4211V23.2632H23.2632V26.4211Z" fill="#EDE1CE"></path></svg></div>Play</a></div><div class="flex items-center space-x-2 sm:space-x-4" bis_skin_checked="1"><TokenSelect /><button class="text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 text-primary-foreground hover:bg-primary/90 w-10 p-[9px] flex justify-center items-center gap-1 rounded-xl bg-white bg-opacity-5 border-[1px] border-customBorder sm:h-[40px] h-[32px]" disabled=""><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="sm:w-5 sm:h-5 w-4 h-4"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path><circle cx="12" cy="12" r="3"></circle></svg></button><button class="text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input hover:text-accent-foreground flex sm:w-[145.97px] w-[40px] h-[40px] px-[13px] py-[8px] justify-center items-center gap-2 rounded-full bg-[rgba(237,225,206,0.05)] transition-colors duration-200 text-white font-bold hover:bg-[rgba(237,225,206,0.2)]"><span class="hidden sm:inline"><UserButton /></span></button></div></div></div></header>


        </div>
      </StyledHeader>
    </>
  )
}
